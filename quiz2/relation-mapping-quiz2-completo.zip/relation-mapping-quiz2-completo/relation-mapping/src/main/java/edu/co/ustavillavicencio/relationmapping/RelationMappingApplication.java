package edu.co.ustavillavicencio.relationmapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationMappingApplication {

    public static void main(String[] args) {
        SpringApplication.run(RelationMappingApplication.class, args);
    }

}
